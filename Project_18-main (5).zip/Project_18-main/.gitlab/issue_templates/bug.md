## Bug Report

**Summary:** [Brief description of the bug]

## Environment

- **OS:** [e.g., Windows 10, macOS Catalina]
- **Browser:** [e.g., Chrome 85, Firefox 80]
- **Shell:** [e.g., bash, zsh, git bash]

## Steps to Reproduce

1. [First step]
2. ...

## Observed Behavior

<!-- What actually happens -->

## Expected Behavior

<!-- What should happen -->

## Impact

<!-- frequency, severity, workaround -->

<!-- ## Additional Context -->

<!-- logs, screenshots, hypotheses -->
