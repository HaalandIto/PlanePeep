## User Story

**As a** [user type]
**I want to** [perform an action]
**So that** [value/benefit is achieved]

## Acceptance Criteria

- [ ] [Describe expected behavior]
- [ ] [Describe an edge case]
- [ ] [Visual or performance requirements]

<!-- ## Design & Context -->
<!-- Link images here of mockups and screenshots -->

<!-- ## Technical Notes -->
<!-- Optional technical notes: Mention specific API endpoints, database changes, or dependencies -->
