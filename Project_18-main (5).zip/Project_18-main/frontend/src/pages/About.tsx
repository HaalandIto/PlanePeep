import { Link } from 'react-router-dom';

export default function About() {
    return (
        <div className='app-page'>
            <div className='app-page__content'>
                <nav className='app-page__nav'>
                    <Link to='/' className='app-page__nav-link'>
                        ← Back
                    </Link>
                </nav>
                <h1 className='app-page__title'>Plane Peep</h1>
                <p className='app-page__tagline'>Built by team t_18.</p>
                <p className='app-page__tagline'>
                    Plane Peep is a live aircraft map and lookup tool. Search by tail number or
                    ICAO24 to open aircraft details, and use your account to personalize the
                    experience.
                </p>
                <section className='app-page__section'>
                    <h2>Current experience</h2>
                    <p>
                        The home page shows aircraft in the current map viewport and refreshes
                        positions automatically. Selecting a plane or searching from the navbar
                        opens a details modal with route, position, and aircraft metadata when
                        available.
                    </p>
                </section>
                <section className='app-page__section'>
                    <h2>Who this app is for</h2>
                    <p>
                        Plane Peep is built for <strong>travelers</strong>,{' '}
                        <strong>aviation enthusiasts</strong>, and anyone who wants quick visibility
                        into live traffic and flight details without leaving the map.
                    </p>
                </section>
                <section className='app-page__section'>
                    <h2>Accounts and favorites</h2>
                    <p>
                        <strong>Login is optional.</strong> Guests can browse the map and search
                        aircraft details. Registered users can sign in, keep a session across page
                        refreshes, and access the Favorites page from the navbar.
                    </p>
                    <p>
                        Favorites UI is currently available for managing saved cards locally in the
                        page session, including:
                    </p>
                    <ul>
                        <li>Reordering saved flights</li>
                        <li>Renaming favorites for quick identification</li>
                        <li>Removing cards you no longer need</li>
                    </ul>
                </section>
                <section className='app-page__section'>
                    <h2>Technology</h2>
                    <ul>
                        <li>React 19 + TypeScript + Vite</li>
                        <li>React Router + React Bootstrap</li>
                        <li>MySQL</li>
                        <li>Java 21 + Spring Boot + Spring Security</li>
                        <li>JWT authentication</li>
                        <li>Caffeine cache + OpenSky/aircraft data integrations</li>
                        <li>Jest/Testing Library (frontend) + JUnit (backend)</li>
                    </ul>
                </section>
                <section className='app-page__section'>
                    <h2>Flight data</h2>
                    <p>
                        Live positions and metadata are fetched through our backend integrations and
                        shown directly on the map and in the aircraft details modal.
                    </p>
                    <p className='app-page__guest-note'>
                        If data is temporarily unavailable, Plane Peep keeps the most recent map
                        view so tracking remains usable.
                    </p>
                    <p className='app-page__attribution'>
                        <a
                            href='https://openskynetwork.github.io/opensky-api/java.html'
                            target='_blank'
                            rel='noopener noreferrer'
                        >
                            OpenSky's
                        </a>{' '}
                        live api and a static registration database power the live data shown in
                        Plane Peep.
                    </p>
                </section>
            </div>
        </div>
    );
}
