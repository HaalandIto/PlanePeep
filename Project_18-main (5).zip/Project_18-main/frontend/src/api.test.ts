/**
 * Unit tests for the API module (src/api.ts).
 *
 * These tests assume every exported function is fully implemented: they perform a real
 * fetch to BASE_URL, use defaultHeaders, parse JSON, and throw an Error with .message
 * and .status when the response is not ok.
 *
 * Setup: We replace global.fetch with jest.fn() before each test and restore it after,
 * so no real HTTP requests are made. Each test configures the mock to resolve or reject
 * with a specific response, then asserts the correct URL, method, headers, body, and
 * return value or thrown error.
 *
 * Run: npm run test:run (single run) or npm run test (watch) from the Frontend directory.
 */
/* eslint-disable @typescript-eslint/no-explicit-any */
const originalFetch = global.fetch;

beforeEach(() => {
    (global as any).fetch = jest.fn();
});

afterEach(() => {
    (global as any).fetch = originalFetch;
});

// Import after fetch mock registration so that when tests run, api methods use the mock
import {
    BASE_URL,
    defaultHeaders,
    withAuthHeaders,
    getHealth,
    postAuthRegister,
    postAuthLogin,
    getAuthMe,
    getAircraftPositions,
    getAircraftMetadata,
    getFavorites,
    postFavorites,
    deleteFavorite,
    patchFavoriteName,
    patchFavoriteOrder,
} from './api';

describe('api', () => {
    describe('exports', () => {
        it('BASE_URL defaults to http://localhost:8000', () => {
            expect(BASE_URL).toBe('http://localhost:8000');
        });

        it('defaultHeaders has Content-Type and Accept', () => {
            expect(defaultHeaders['Content-Type']).toBe('application/json');
            expect(defaultHeaders['Accept']).toBe('application/json');
        });

        it('withAuthHeaders adds Authorization when token is provided', () => {
            expect(withAuthHeaders('tkn')).toEqual({
                ...defaultHeaders,
                Authorization: 'Bearer tkn',
            });
        });
    });

    describe('getHealth', () => {
        it('calls GET /api/health and returns body', async () => {
            const body = 'ok';
            (global.fetch as jest.Mock).mockResolvedValueOnce({
                ok: true,
                json: () => Promise.resolve(body),
            });
            const result = await getHealth();
            expect(global.fetch).toHaveBeenCalledTimes(1);
            expect(global.fetch).toHaveBeenCalledWith(
                `${BASE_URL}/api/health`,
                expect.objectContaining({ method: 'GET', headers: defaultHeaders }),
            );
            expect(result).toBe(body);
        });

        it('throws on !res.ok with error message and status', async () => {
            (global.fetch as jest.Mock).mockResolvedValueOnce({
                ok: false,
                status: 503,
                statusText: 'Service Unavailable',
                json: () => Promise.resolve({ error: 'unavailable' }),
            });
            await expect(getHealth()).rejects.toMatchObject({
                message: 'unavailable',
                status: 503,
            });
        });
    });

    describe('postAuthRegister', () => {
        it('calls POST /api/auth/register with body and returns on 201', async () => {
            const authBody = {
                userId: 1,
                username: 'u',
            };
            (global.fetch as jest.Mock).mockResolvedValueOnce({
                ok: true,
                status: 201,
                json: () => Promise.resolve(authBody),
            });
            const result = await postAuthRegister({
                username: 'u',
                password: 'p',
            });
            expect(global.fetch).toHaveBeenCalledTimes(1);
            expect(global.fetch).toHaveBeenCalledWith(
                `${BASE_URL}/api/auth/register`,
                expect.objectContaining({
                    method: 'POST',
                    headers: defaultHeaders,
                    body: JSON.stringify({ username: 'u', password: 'p' }),
                }),
            );
            expect(result).toEqual(authBody);
        });

        it('throws on 409 with error message and status', async () => {
            (global.fetch as jest.Mock).mockResolvedValueOnce({
                ok: false,
                status: 409,
                statusText: 'Conflict',
                json: () => Promise.resolve({ error: 'username already exists' }),
            });
            await expect(postAuthRegister({ username: 'u', password: 'p' })).rejects.toMatchObject({
                message: 'username already exists',
                status: 409,
            });
        });
    });

    describe('postAuthLogin', () => {
        it('calls POST /api/auth/login with body and returns on 200', async () => {
            const authBody = {
                userId: 1,
                username: 'u',
                token: 'jwt-token',
            };
            (global.fetch as jest.Mock).mockResolvedValueOnce({
                ok: true,
                status: 200,
                json: () => Promise.resolve(authBody),
            });
            const result = await postAuthLogin({ username: 'u', password: 'p' });
            expect(global.fetch).toHaveBeenCalledTimes(1);
            expect(global.fetch).toHaveBeenCalledWith(
                `${BASE_URL}/api/auth/login`,
                expect.objectContaining({
                    method: 'POST',
                    headers: defaultHeaders,
                    body: JSON.stringify({ username: 'u', password: 'p' }),
                }),
            );
            expect(result).toEqual(authBody);
        });

        it('throws on 401 with error message and status', async () => {
            (global.fetch as jest.Mock).mockResolvedValueOnce({
                ok: false,
                status: 401,
                statusText: 'Unauthorized',
                json: () => Promise.resolve({ error: 'invalid credentials' }),
            });
            await expect(postAuthLogin({ username: 'u', password: 'wrong' })).rejects.toMatchObject(
                {
                    message: 'invalid credentials',
                    status: 401,
                },
            );
        });
    });

    describe('getAuthMe', () => {
        it('calls GET /api/auth/me with Authorization header', async () => {
            const authBody = { userId: 1, username: 'u', token: 'jwt' };
            (global.fetch as jest.Mock).mockResolvedValueOnce({
                ok: true,
                status: 200,
                json: () => Promise.resolve(authBody),
            });
            const result = await getAuthMe('jwt');
            expect(global.fetch).toHaveBeenCalledWith(
                `${BASE_URL}/api/auth/me`,
                expect.objectContaining({
                    method: 'GET',
                    headers: expect.objectContaining({
                        ...defaultHeaders,
                        Authorization: 'Bearer jwt',
                    }),
                }),
            );
            expect(result).toEqual(authBody);
        });
    });

    describe('getAircraftPositions', () => {
        it('calls GET /api/aircraft/positions with query params and returns array', async () => {
            const list = [{ icao24: 'a', latitude: 1 }];
            (global.fetch as jest.Mock).mockResolvedValueOnce({
                ok: true,
                json: () => Promise.resolve(list),
            });
            const result = await getAircraftPositions({
                minLat: 1,
                maxLat: 2,
                minLon: 3,
                maxLon: 4,
            });
            expect(global.fetch).toHaveBeenCalledTimes(1);
            const url = (global.fetch as jest.Mock).mock.calls[0][0];
            expect(url).toContain('/api/aircraft/positions');
            expect(url).toContain('minLat=1');
            expect(url).toContain('maxLat=2');
            expect(url).toContain('minLon=3');
            expect(url).toContain('maxLon=4');
            expect(global.fetch).toHaveBeenCalledWith(
                url,
                expect.objectContaining({ method: 'GET', headers: defaultHeaders }),
            );
            expect(result).toEqual(list);
        });

        it('throws on !res.ok', async () => {
            (global.fetch as jest.Mock).mockResolvedValueOnce({
                ok: false,
                status: 500,
                statusText: 'Server Error',
                json: () => Promise.resolve({ error: 'server error' }),
            });
            await expect(
                getAircraftPositions({ minLat: 0, maxLat: 1, minLon: 0, maxLon: 1 }),
            ).rejects.toMatchObject({ message: 'server error', status: 500 });
        });
    });

    describe('getAircraftMetadata', () => {
        it('calls GET /api/aircraft/metadata/{icao24} and returns object', async () => {
            const meta = { icao24: 'abc123', model: 'B738' };
            (global.fetch as jest.Mock).mockResolvedValueOnce({
                ok: true,
                json: () => Promise.resolve(meta),
            });
            const result = await getAircraftMetadata('abc123');
            expect(global.fetch).toHaveBeenCalledTimes(1);
            expect(global.fetch).toHaveBeenCalledWith(
                `${BASE_URL}/api/aircraft/metadata/abc123`,
                expect.objectContaining({ method: 'GET', headers: defaultHeaders }),
            );
            expect(result).toEqual(meta);
        });

        it('throws on 404', async () => {
            (global.fetch as jest.Mock).mockResolvedValueOnce({
                ok: false,
                status: 404,
                statusText: 'Not Found',
                json: () => Promise.resolve({ error: 'not found' }),
            });
            await expect(getAircraftMetadata('unknown')).rejects.toMatchObject({
                message: 'not found',
                status: 404,
            });
        });
    });

    describe('getFavorites', () => {
        it('calls GET /api/favorites and returns normalized FavoriteListItem[]', async () => {
            const list = [
                { favoriteId: 1, name: 'Favorite', externalItemId: 'ext-1', sortOrder: 0 },
            ];
            (global.fetch as jest.Mock).mockResolvedValueOnce({
                ok: true,
                json: () => Promise.resolve(list),
            });
            const result = await getFavorites();
            expect(global.fetch).toHaveBeenCalledTimes(1);
            expect(global.fetch).toHaveBeenCalledWith(
                `${BASE_URL}/api/favorites`,
                expect.objectContaining({ method: 'GET', headers: defaultHeaders }),
            );
            expect(result).toEqual([
                {
                    favoriteId: 1,
                    name: 'Favorite',
                    sortOrder: 0,
                    externalItemId: 'ext-1',
                    typecode: null,
                    tailNumber: null,
                    updatedAt: '',
                    createdAt: '',
                },
            ]);
        });

        it('throws on !res.ok', async () => {
            (global.fetch as jest.Mock).mockResolvedValueOnce({
                ok: false,
                status: 401,
                json: () => Promise.resolve({ error: 'unauthorized' }),
            });
            await expect(getFavorites()).rejects.toMatchObject({
                message: 'unauthorized',
                status: 401,
            });
        });
    });

    describe('postFavorites', () => {
        it('calls POST /api/favorites with body and returns on 201', async () => {
            const created = { id: 1, externalItemId: 'x' };
            (global.fetch as jest.Mock).mockResolvedValueOnce({
                ok: true,
                status: 201,
                json: () => Promise.resolve(created),
            });
            const result = await postFavorites({ externalItemId: 'x' });
            expect(global.fetch).toHaveBeenCalledTimes(1);
            expect(global.fetch).toHaveBeenCalledWith(
                `${BASE_URL}/api/favorites`,
                expect.objectContaining({
                    method: 'POST',
                    headers: defaultHeaders,
                    body: JSON.stringify({ externalItemId: 'x' }),
                }),
            );
            expect(result).toEqual(created);
        });

        it('sends Authorization Bearer when token is passed', async () => {
            const created = { id: 1, externalItemId: 'x' };
            (global.fetch as jest.Mock).mockResolvedValueOnce({
                ok: true,
                status: 201,
                json: () => Promise.resolve(created),
            });
            await postFavorites({ externalItemId: 'x' }, 'my-jwt');
            expect(global.fetch).toHaveBeenCalledWith(
                `${BASE_URL}/api/favorites`,
                expect.objectContaining({
                    method: 'POST',
                    headers: {
                        ...defaultHeaders,
                        Authorization: 'Bearer my-jwt',
                    },
                    body: JSON.stringify({ externalItemId: 'x' }),
                }),
            );
        });

        it('throws on 400', async () => {
            (global.fetch as jest.Mock).mockResolvedValueOnce({
                ok: false,
                status: 400,
                json: () => Promise.resolve({ error: 'invalid' }),
            });
            await expect(postFavorites({})).rejects.toMatchObject({
                message: 'invalid',
                status: 400,
            });
        });
    });

    describe('deleteFavorite', () => {
        it('calls DELETE /api/favorites/{favoriteId} and resolves', async () => {
            (global.fetch as jest.Mock).mockResolvedValueOnce({
                ok: true,
                status: 204,
                json: () => Promise.resolve({}),
            });
            const result = await deleteFavorite('fav-1');
            expect(global.fetch).toHaveBeenCalledTimes(1);
            expect(global.fetch).toHaveBeenCalledWith(
                `${BASE_URL}/api/favorites/fav-1`,
                expect.objectContaining({ method: 'DELETE', headers: defaultHeaders }),
            );
            expect(result).toEqual({});
        });

        it('throws on 404', async () => {
            (global.fetch as jest.Mock).mockResolvedValueOnce({
                ok: false,
                status: 404,
                json: () => Promise.resolve({ error: 'not found' }),
            });
            await expect(deleteFavorite('missing')).rejects.toMatchObject({
                message: 'not found',
                status: 404,
            });
        });
    });

    describe('patchFavoriteName', () => {
        it('calls PATCH /api/favorites/{favoriteId} with body { name } and returns', async () => {
            const updated = { id: 1, name: 'My Flight' };
            (global.fetch as jest.Mock).mockResolvedValueOnce({
                ok: true,
                json: () => Promise.resolve(updated),
            });
            const result = await patchFavoriteName('fav-1', 'My Flight');
            expect(global.fetch).toHaveBeenCalledTimes(1);
            expect(global.fetch).toHaveBeenCalledWith(
                `${BASE_URL}/api/favorites/fav-1/name`,
                expect.objectContaining({
                    method: 'PATCH',
                    headers: defaultHeaders,
                    body: JSON.stringify({ name: 'My Flight' }),
                }),
            );
            expect(result).toEqual(updated);
        });

        it('throws on !res.ok', async () => {
            (global.fetch as jest.Mock).mockResolvedValueOnce({
                ok: false,
                status: 400,
                json: () => Promise.resolve({ error: 'bad request' }),
            });
            await expect(patchFavoriteName('fav-1', '')).rejects.toMatchObject({
                message: 'bad request',
                status: 400,
            });
        });
    });

    describe('patchFavoriteOrder', () => {
        it('calls PATCH with direction "up" and returns', async () => {
            (global.fetch as jest.Mock).mockResolvedValueOnce({ ok: true });
            const result = await patchFavoriteOrder('fav-1', 'up');
            expect(global.fetch).toHaveBeenCalledWith(
                `${BASE_URL}/api/favorites/fav-1/order`,
                expect.objectContaining({
                    method: 'PATCH',
                    body: JSON.stringify({ direction: 'up' }),
                }),
            );
            expect(result).toBeUndefined();
        });

        it('calls PATCH with direction "down"', async () => {
            (global.fetch as jest.Mock).mockResolvedValueOnce({
                ok: true,
                json: () => Promise.resolve({}),
            });
            await patchFavoriteOrder('fav-1', 'down');
            expect(global.fetch).toHaveBeenCalledWith(
                `${BASE_URL}/api/favorites/fav-1/order`,
                expect.objectContaining({
                    body: JSON.stringify({ direction: 'down' }),
                }),
            );
        });

        it('throws on !res.ok', async () => {
            (global.fetch as jest.Mock).mockResolvedValueOnce({
                ok: false,
                status: 404,
                json: () => Promise.resolve({ error: 'not found' }),
            });
            await expect(patchFavoriteOrder('fav-1', 'up')).rejects.toMatchObject({
                message: 'not found',
                status: 404,
            });
        });
    });
});
